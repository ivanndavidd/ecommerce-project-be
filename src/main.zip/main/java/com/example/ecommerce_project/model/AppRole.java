package com.example.ecommerce_project.model;

public enum AppRole {
    ROLE_USER,
    ROLE_SELLER,
    ROLE_ADMIN
}
